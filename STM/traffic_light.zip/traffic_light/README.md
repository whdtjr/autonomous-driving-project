# STM 핀 구성
Green_Pin   : PB06  
Yellow_Pin  : PB05  
Red_Pin     : PB04  

![alt text](image.png)
